<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'username',
        'email',
        'password',
        'role',
        'status',
        'phone',
        'telepon',
        'last_login_at',
        'last_login_ip',
    ];

    protected $appends = [
        'telepon',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'last_login_at' => 'datetime',
        'password' => 'hashed',
    ];

    public function getTeleponAttribute()
    {
        return $this->attributes['phone'] ?? ($this->attributes['telepon'] ?? null);
    }

    public function setTeleponAttribute($value)
    {
        $this->attributes['phone'] = $value;
    }

    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    public function isKepala(): bool
    {
        return in_array(strtolower((string)$this->role), [
            'kepala',
            'pimpinan',
            'kepala_balai',
            'kepala_bblkl',
            'pimpinan_bblkl'
        ]);
    }

    public function canApproveRekomendasi(): bool
    {
        return $this->isAdmin() || $this->isKepala();
    }


    public function isDirektorat(): bool
    {
        return strtolower((string)$this->role) === 'direktorat';
    }

    public function canManageUsers(): bool
    {
        return in_array(strtolower((string)$this->role), [
            'admin',
            'kepala',
            'pimpinan',
            'kepala_balai',
            'kepala_bblkl',
            'pimpinan_bblkl'
        ]);
    }

    public function canBackupRestore(): bool
    {
        return !$this->isViewer();
    }

    public function isPetugas(): bool
    {
        return in_array($this->role, [
            'admin',
            'petugas',
            'direktorat',
            'dinas_kesehatan',
            'dinkes',
            'balai_kekarantinaan_kesehatan',
            'bkk',
            'balai_karantina',
            'labkesmas',
            'peneliti',
            'universitas',
        ]);
    }

    public function isViewer(): bool
    {
        return strtolower((string)$this->role) === 'viewer';
    }

    public function isPeneliti(): bool
    {
        return strtolower((string)$this->role) === 'peneliti';
    }

    public function isUniversitas(): bool
    {
        return in_array(strtolower((string)$this->role), ['universitas', 'akademisi']);
    }

    public function canManageData(): bool
    {
        return !$this->isViewer();
    }

    public function canSeeAllData(): bool
    {
        return $this->isAdmin() || $this->isViewer() || $this->isKepala();
    }

    public function getBackupFileIdentifier(): string
    {
        $raw = !empty($this->username) ? $this->username : $this->name;
        $slug = preg_replace('/[^a-zA-Z0-9_\-]/', '_', strtolower(trim((string)$raw)));
        $slug = preg_replace('/_+/', '_', (string)$slug);
        return trim($slug, '_') ?: 'user_' . $this->id;
    }

    public function dataUjiResistensi()
    {
        return $this->hasMany(DataUjiResistensi::class, 'user_id');
    }

    public function isActive(): bool
    {
        return $this->status === 'aktif';
    }
}
