<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class AdminOnly
{
    /**
     * Memastikan hanya pengguna dengan hak akses role Administrator yang dapat mengakses rute ini.
     */
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Silakan masuk terlebih dahulu dengan akun Administrator untuk mengakses halaman ini.');
        }

        if (strtolower((string)Auth::user()->role) !== 'admin') {
            if ($request->expectsJson() || $request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Akses Ditolak: Halaman ini hanya dapat diakses oleh Administrator.'
                ], 403);
            }

            return redirect()->route('dashboard')->with('error', 'Akses Ditolak: Menu Rekomendasi Kebijakan & Master Data hanya dapat diakses oleh Administrator.');
        }

        return $next($request);
    }
}
