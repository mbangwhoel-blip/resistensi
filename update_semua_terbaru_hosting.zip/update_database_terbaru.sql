-- ============================================================
-- SQL UPDATE TERBARU RESISTENSI (KEMENKES BBLKL)
-- Jalankan di phpMyAdmin / MySQL cPanel database
-- ============================================================

-- 1. Update Koordinat Jepara (Di daratan Jepara, bukan di laut)
UPDATE kabupatens SET latitude = '-6.5936000', longitude = '110.6778000' WHERE id = 159;

-- 2. Sinkronisasi Data Kota & Kabupaten (Semarang, Depok, Jakarta, Sorong, dll.)
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (161, 13, 'Kabupaten Semarang', '-7.2928000', '110.4987000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 13, name = 'Kabupaten Semarang', latitude = '-7.2928000', longitude = '110.4987000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (405, 34, 'Kabupaten Sorong', '-1.1060000', '131.4558000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 34, name = 'Kabupaten Sorong', latitude = '-1.1060000', longitude = '131.4558000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (416, 34, 'Pegunungan Arfak', '-1.1719740', '133.8171610', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 34, name = 'Pegunungan Arfak', latitude = '-1.1719740', longitude = '133.8171610', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (417, 13, 'Kota Salatiga', '-7.3333930', '110.5032650', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 13, name = 'Kota Salatiga', latitude = '-7.3333930', longitude = '110.5032650', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (418, 28, 'Kota Kendari', '-3.9915000', '122.5670000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 28, name = 'Kota Kendari', latitude = '-3.9915000', longitude = '122.5670000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (419, 27, 'Kota Makassar', '-5.1477000', '119.4327000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 27, name = 'Kota Makassar', latitude = '-5.1477000', longitude = '119.4327000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (420, 5, 'Batang Hari', '-1.7167000', '103.1167000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 5, name = 'Batang Hari', latitude = '-1.7167000', longitude = '103.1167000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (421, 10, 'Kota Tanjung Pinang', '0.9167000', '104.4500000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 10, name = 'Kota Tanjung Pinang', latitude = '0.9167000', longitude = '104.4500000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (422, 4, 'Kota Pekanbaru', '0.5071000', '101.4478000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 4, name = 'Kota Pekanbaru', latitude = '0.5071000', longitude = '101.4478000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (423, 14, 'Kota Yogyakarta', '-7.7956000', '110.3695000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 14, name = 'Kota Yogyakarta', latitude = '-7.7956000', longitude = '110.3695000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (424, 26, 'Kota Palu', '-0.9003000', '119.8779000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 26, name = 'Kota Palu', latitude = '-0.9003000', longitude = '119.8779000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (425, 2, 'Kota Medan', '3.5952000', '98.6722000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 2, name = 'Kota Medan', latitude = '3.5952000', longitude = '98.6722000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (426, 22, 'Kota Banjarmasin', '-3.2950000', '114.5900000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 22, name = 'Kota Banjarmasin', latitude = '-3.2950000', longitude = '114.5900000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (427, 15, 'Kota Surabaya', '-7.2575000', '112.7521000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 15, name = 'Kota Surabaya', latitude = '-7.2575000', longitude = '112.7521000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (428, 11, 'Kota Jakarta Timur', '-6.2250000', '106.9004000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 11, name = 'Kota Jakarta Timur', latitude = '-6.2250000', longitude = '106.9004000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (429, 25, 'Kota Manado', '1.4748000', '124.8428000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 25, name = 'Kota Manado', latitude = '1.4748000', longitude = '124.8428000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (431, 31, 'Kota Ambon', '-3.6954000', '128.1814000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 31, name = 'Kota Ambon', latitude = '-3.6954000', longitude = '128.1814000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (432, 12, 'Kota Depok', '-6.4025000', '106.7942000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 12, name = 'Kota Depok', latitude = '-6.4025000', longitude = '106.7942000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (433, 13, 'Kota Semarang', '-6.9667000', '110.4203000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 13, name = 'Kota Semarang', latitude = '-6.9667000', longitude = '110.4203000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (434, 13, 'Kota Magelang', '-7.4757000', '110.2206000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 13, name = 'Kota Magelang', latitude = '-7.4757000', longitude = '110.2206000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (435, 13, 'Kota Surakarta', '-7.5666000', '110.8167000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 13, name = 'Kota Surakarta', latitude = '-7.5666000', longitude = '110.8167000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (436, 13, 'Kota Pekalongan', '-6.8981000', '109.6758000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 13, name = 'Kota Pekalongan', latitude = '-6.8981000', longitude = '109.6758000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (437, 13, 'Kota Tegal', '-6.8767000', '109.1192000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 13, name = 'Kota Tegal', latitude = '-6.8767000', longitude = '109.1192000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (439, 12, 'Kota Bandung', '-6.8951000', '107.6443000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 12, name = 'Kota Bandung', latitude = '-6.8951000', longitude = '107.6443000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (440, 12, 'Kota Bogor', '-6.5865000', '106.7892000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 12, name = 'Kota Bogor', latitude = '-6.5865000', longitude = '106.7892000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (441, 12, 'Kota Bekasi', '-6.3084000', '106.9638000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 12, name = 'Kota Bekasi', latitude = '-6.3084000', longitude = '106.9638000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (442, 12, 'Kota Cirebon', '-6.7386000', '108.5542000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 12, name = 'Kota Cirebon', latitude = '-6.7386000', longitude = '108.5542000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (443, 12, 'Kota Sukabumi', '-6.9421000', '106.9157000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 12, name = 'Kota Sukabumi', latitude = '-6.9421000', longitude = '106.9157000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (444, 12, 'Kota Tasikmalaya', '-7.3575000', '108.2336000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 12, name = 'Kota Tasikmalaya', latitude = '-7.3575000', longitude = '108.2336000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (445, 15, 'Kota Blitar', '-8.0980000', '112.1658000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 15, name = 'Kota Blitar', latitude = '-8.0980000', longitude = '112.1658000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (446, 15, 'Kota Kediri', '-7.8297000', '112.0318000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 15, name = 'Kota Kediri', latitude = '-7.8297000', longitude = '112.0318000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (447, 15, 'Kota Madiun', '-7.6270000', '111.5299000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 15, name = 'Kota Madiun', latitude = '-7.6270000', longitude = '111.5299000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (448, 15, 'Kota Malang', '-7.9719000', '112.6245000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 15, name = 'Kota Malang', latitude = '-7.9719000', longitude = '112.6245000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (449, 15, 'Kota Mojokerto', '-7.4734000', '112.4368000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 15, name = 'Kota Mojokerto', latitude = '-7.4734000', longitude = '112.4368000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (450, 15, 'Kota Pasuruan', '-7.6503000', '112.9058000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 15, name = 'Kota Pasuruan', latitude = '-7.6503000', longitude = '112.9058000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (451, 15, 'Kota Probolinggo', '-7.7679000', '113.2097000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 15, name = 'Kota Probolinggo', latitude = '-7.7679000', longitude = '113.2097000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (452, 16, 'Kota Tangerang', '-6.1934000', '106.6497000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 16, name = 'Kota Tangerang', latitude = '-6.1934000', longitude = '106.6497000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (453, 16, 'Kota Serang', '-6.1247000', '106.1642000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 16, name = 'Kota Serang', latitude = '-6.1247000', longitude = '106.1642000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (454, 3, 'Kota Solok', '-0.7876000', '100.6268000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 3, name = 'Kota Solok', latitude = '-0.7876000', longitude = '100.6268000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (455, 37, 'Kota Sorong', '-0.8690000', '131.3274000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 37, name = 'Kota Sorong', latitude = '-0.8690000', longitude = '131.3274000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (456, 33, 'Kota Jayapura', '-2.5897000', '140.7323000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 33, name = 'Kota Jayapura', latitude = '-2.5897000', longitude = '140.7323000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (457, 29, 'Kota Gorontalo', '0.5349000', '123.0472000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 29, name = 'Kota Gorontalo', latitude = '0.5349000', longitude = '123.0472000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (458, 19, 'Kota Kupang', '-10.1985000', '123.6137000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 19, name = 'Kota Kupang', latitude = '-10.1985000', longitude = '123.6137000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (459, 18, 'Kota Bima', '-8.4408000', '118.7533000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 18, name = 'Kota Bima', latitude = '-8.4408000', longitude = '118.7533000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (460, 12, 'Kota Banjar', '-7.3765000', '108.5621000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 12, name = 'Kota Banjar', latitude = '-7.3765000', longitude = '108.5621000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (461, 11, 'Kota Jakarta Pusat', '-6.1805000', '106.8284000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 11, name = 'Kota Jakarta Pusat', latitude = '-6.1805000', longitude = '106.8284000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (462, 11, 'Kota Jakarta Utara', '-6.1384000', '106.8640000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 11, name = 'Kota Jakarta Utara', latitude = '-6.1384000', longitude = '106.8640000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (463, 11, 'Kota Jakarta Barat', '-6.1683000', '106.7588000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 11, name = 'Kota Jakarta Barat', latitude = '-6.1683000', longitude = '106.7588000', updated_at = NOW();
INSERT INTO kabupatens (id, provinsi_id, name, latitude, longitude, created_at, updated_at) VALUES (464, 11, 'Kota Jakarta Selatan', '-6.2615000', '106.8106000', NOW(), NOW()) ON DUPLICATE KEY UPDATE provinsi_id = 11, name = 'Kota Jakarta Selatan', latitude = '-6.2615000', longitude = '106.8106000', updated_at = NOW();

-- 3. Update Data Uji Pelabuhan Tanjung Mas ke Kota Semarang
UPDATE data_uji_resistensis SET kabupaten_id = 433 WHERE id = 317;

-- 4. Perluas kolom role tabel users agar mendukung nama role baru
ALTER TABLE users MODIFY role VARCHAR(50) NOT NULL DEFAULT 'petugas';

-- 5. Sinkronisasi Data Uji Kabupaten Madiun ke Provinsi Jawa Timur (ID 15)
UPDATE data_uji_resistensis SET provinsi_id = 15 WHERE kabupaten_id = 191;

-- 6. Penyelarasan Wilayah Pemekaran Papua (DOB)
UPDATE kabupatens SET provinsi_id = 35 WHERE id = 385; -- Mimika -> Papua Tengah
UPDATE kabupatens SET provinsi_id = 36 WHERE id = 392; -- Boven Digoel -> Papua Selatan
UPDATE data_uji_resistensis SET provinsi_id = 35 WHERE kabupaten_id = 385;
UPDATE data_uji_resistensis SET provinsi_id = 36 WHERE kabupaten_id = 392;

-- 7. Tabel Persetujuan / Approval Rekomendasi Kebijakan oleh Kepala/Pimpinan BBLKL
CREATE TABLE IF NOT EXISTS `rekomendasi_approvals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `doc_hash` varchar(64) NOT NULL,
  `filter_scope` varchar(64) NOT NULL,
  `template` varchar(50) NOT NULL DEFAULT 'all',
  `tahun` varchar(20) NOT NULL DEFAULT 'Semua',
  `jenis_nyamuk` varchar(100) NOT NULL DEFAULT 'Semua',
  `provinsi_id` varchar(50) NOT NULL DEFAULT 'Semua',
  `kabupaten_id` varchar(50) NOT NULL DEFAULT 'Semua',
  `nama_wilayah` varchar(255) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'draft',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `approver_name` varchar(150) DEFAULT NULL,
  `approver_nip` varchar(50) DEFAULT NULL,
  `approver_jabatan` varchar(255) DEFAULT NULL,
  `nomor_surat` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `verification_token` varchar(64) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rekomendasi_approvals_doc_hash_index` (`doc_hash`),
  KEY `rekomendasi_approvals_filter_scope_index` (`filter_scope`),
  KEY `rekomendasi_approvals_status_index` (`status`),
  KEY `rekomendasi_approvals_verification_token_index` (`verification_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Tambahkan kolom koordinat latitude & longitude di tabel data_uji_resistensis (jika belum ada)
ALTER TABLE `data_uji_resistensis` ADD COLUMN IF NOT EXISTS `latitude` decimal(10,8) NULL AFTER `address`;
ALTER TABLE `data_uji_resistensis` ADD COLUMN IF NOT EXISTS `longitude` decimal(11,8) NULL AFTER `latitude`;
