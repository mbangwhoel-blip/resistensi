<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('kabupatens', function (Blueprint $table) {
    $table->id();

    $table->foreignId('provinsi_id')
        ->constrained('provinsis')
        ->cascadeOnDelete();

    $table->string('nama_kabupaten');

    $table->timestamps();

    $table->unique(['provinsi_id', 'nama_kabupaten']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('kabupatens');
    }
};