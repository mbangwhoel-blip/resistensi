-- =====================================================
-- SIMPEL BBLKL Database Backup
-- Generated: 2026-10-07 04:34:32
-- Database: db_simpel
-- =====================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';

-- -----------------------------------------------------
-- Table structure for `data_uji_resistensis`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `data_uji_resistensis`;
CREATE TABLE `data_uji_resistensis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bulan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tahun` int DEFAULT NULL,
  `provinsi_id` bigint unsigned NOT NULL,
  `kabupaten_id` bigint unsigned NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `jenis_nyamuk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `insektisida` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sampel_diperiksa` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `data_uji_resistensis_provinsi_id_foreign` (`provinsi_id`),
  KEY `data_uji_resistensis_kabupaten_id_foreign` (`kabupaten_id`),
  CONSTRAINT `data_uji_resistensis_kabupaten_id_foreign` FOREIGN KEY (`kabupaten_id`) REFERENCES `kabupatens` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `data_uji_resistensis_provinsi_id_foreign` FOREIGN KEY (`provinsi_id`) REFERENCES `provinsis` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `data_uji_resistensis`
INSERT INTO `data_uji_resistensis` VALUES (1, 1, 'Oktober', 2026, 17, 211, NULL, 'Ae. aegypti', 'Cypermethrin', 'CDC bottle bioassay', 1, '2026-10-07 01:47:29', '2026-10-07 02:07:49');
INSERT INTO `data_uji_resistensis` VALUES (2, 1, 'Oktober', 2026, 29, 350, NULL, 'Aedes sp', 'Malathion', 'WHO Tube Bioassay', 1, '2026-10-07 02:04:38', '2026-10-07 02:04:38');
INSERT INTO `data_uji_resistensis` VALUES (3, 3, 'Oktober', 2026, 1, 5, NULL, 'Ae. aegypti', 'Cypermethrin', 'CDC bottle bioassay', 25, '2026-10-07 02:08:26', '2026-10-07 02:08:26');
INSERT INTO `data_uji_resistensis` VALUES (4, 4, 'Oktober', 2026, 1, 5, NULL, 'Culex sp', 'Malathion', 'WHO Tube Bioassay', 50, '2026-10-07 02:08:26', '2026-10-07 02:08:26');
INSERT INTO `data_uji_resistensis` VALUES (5, 5, 'Oktober', 2026, 1, 5, 'RT 05/RW 02 Desa Meulaboh Barat, Poskesdes Pahlawan', 'Ae. aegypti', 'Deltamethrin', 'WHO Tube Bioassay', 90, '2026-10-07 02:17:48', '2026-10-07 02:17:48');

-- -----------------------------------------------------
-- Table structure for `delete_requests`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `delete_requests`;
CREATE TABLE `delete_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `data_uji_resistensi_id` bigint unsigned DEFAULT NULL,
  `alasan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `delete_requests_data_uji_resistensi_id_foreign` (`data_uji_resistensi_id`),
  CONSTRAINT `delete_requests_data_uji_resistensi_id_foreign` FOREIGN KEY (`data_uji_resistensi_id`) REFERENCES `data_uji_resistensis` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------
-- Table structure for `failed_jobs`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------
-- Table structure for `instansis`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `instansis`;
CREATE TABLE `instansis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama_instansi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kode_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kategori` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Balai / Laboratorium',
  `provinsi_id` bigint unsigned DEFAULT NULL,
  `kabupaten_id` bigint unsigned DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `telepon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `penanggung_jawab` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `instansis_provinsi_id_foreign` (`provinsi_id`),
  KEY `instansis_kabupaten_id_foreign` (`kabupaten_id`),
  CONSTRAINT `instansis_kabupaten_id_foreign` FOREIGN KEY (`kabupaten_id`) REFERENCES `kabupatens` (`id`) ON DELETE SET NULL,
  CONSTRAINT `instansis_provinsi_id_foreign` FOREIGN KEY (`provinsi_id`) REFERENCES `provinsis` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `instansis`
INSERT INTO `instansis` VALUES (1, 'Balai Besar Laboratorium Kesehatan Lingkungan (BBLKL)', 'BBLKL-01', 'Balai / Laboratorium', 13, 417, 'Jl. Hasanudin No 123 Salatiga', 085196695758, 'bblkl.salatiga@kemkes.go.id', 'Kepala Balai BBLKL', '2026-10-07 01:51:59', '2026-10-07 02:03:24');
INSERT INTO `instansis` VALUES (3, 'Kementerian Kesehatan RI', 'KEMKES-PST', 'Kementerian / Lembaga', 11, NULL, 'Jl. H.R. Rasuna Said Blok X.5 Kav. 4-9, Jakarta', '(021) 5201590', 'kontak@kemkes.go.id', 'Direktorat Kesling', '2026-10-07 01:51:59', '2026-10-07 01:51:59');
INSERT INTO `instansis` VALUES (4, 'DKK Semarang', 'DKK-01', 'Dinas Kesehatan', 13, 161, NULL, NULL, NULL, NULL, '2026-10-07 02:18:38', '2026-10-07 02:19:19');

-- -----------------------------------------------------
-- Table structure for `kabupatens`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `kabupatens`;
CREATE TABLE `kabupatens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `provinsi_id` bigint unsigned NOT NULL,
  `nama_kabupaten` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kabupatens_provinsi_id_nama_kabupaten_unique` (`provinsi_id`,`nama_kabupaten`),
  CONSTRAINT `kabupatens_provinsi_id_foreign` FOREIGN KEY (`provinsi_id`) REFERENCES `provinsis` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=418 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `kabupatens`
INSERT INTO `kabupatens` VALUES (1, 1, 'Aceh Selatan', 3.2798000, 97.2885000, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (2, 1, 'Aceh Tenggara', 3.3768000, 97.8091000, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (3, 1, 'Aceh Timur', 4.7932000, 97.7617000, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (4, 1, 'Aceh Tengah', 4.5445000, 96.8522000, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (5, 1, 'Aceh Barat', 4.1449000, 96.1527000, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (6, 1, 'Aceh Besar', 5.3786000, 95.5303000, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (7, 1, 'Pidie', 5.2346000, 95.9610000, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (8, 1, 'Aceh Utara', 5.0117000, 97.1420000, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (9, 1, 'Simeulue', 4.8695650, 97.2526040, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (10, 1, 'Aceh Singkil', 4.9362260, 96.1382530, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (11, 1, 'Bireuen', 4.5591890, 96.8159610, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (12, 1, 'Aceh Barat Daya', 4.9526390, 96.8346490, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (13, 1, 'Gayo Lues', 4.5001350, 96.3947620, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (14, 1, 'Aceh Jaya', 4.5847510, 97.2722060, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (15, 1, 'Nagan Raya', 5.2112010, 96.3699780, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (16, 1, 'Aceh Tamiang', 4.5464180, 96.7288410, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (17, 1, 'Bener Meriah', 4.8686880, 96.9665730, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (18, 1, 'Pidie Jaya', 4.7121470, 96.3402890, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (19, 2, 'Tapanuli Tengah', 1.7547300, 99.9237530, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (20, 2, 'Tapanuli Utara', 2.7447540, 99.5162430, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (21, 2, 'Tapanuli Selatan', 2.0004470, 99.4438580, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (22, 2, 'Nias', 2.1505960, 99.8261720, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (23, 2, 'Langkat', 2.3390490, 99.2096540, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (24, 2, 'Karo', 1.6174430, 99.6610000, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (25, 2, 'Deli Serdang', 2.6609500, 99.8758470, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (26, 2, 'Simalungun', 2.0702480, 99.3948870, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (27, 2, 'Asahan', 2.0012470, 99.8020350, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (28, 2, 'Labuhanbatu', 2.4756670, 99.3883880, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (29, 2, 'Dairi', 1.6361110, 99.3619450, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (30, 2, 'Toba', 2.4062560, 100.1318550, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (31, 2, 'Mandailing Natal', 2.1541770, 99.3929640, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (32, 2, 'Nias Selatan', 1.8876380, 99.6974210, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (33, 2, 'Pakpak Bharat', 2.4994290, 99.6162060, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (34, 2, 'Humbang Hasundutan', 1.8048860, 99.1202560, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (35, 2, 'Samosir', 2.0604460, 100.2040800, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (36, 2, 'Serdang Bedagai', 2.2259460, 99.4386920, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (37, 2, 'Batu Bara', 1.8453540, 99.5450970, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (38, 2, 'Padang Lawas Utara', 2.4028920, 99.8217510, '2026-10-07 01:37:48', '2026-10-07 02:29:16');
INSERT INTO `kabupatens` VALUES (39, 2, 'Padang Lawas', 2.0709050, 99.0116350, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (40, 2, 'Labuhanbatu Selatan', 1.7318340, 100.0699000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (41, 2, 'Labuhanbatu Utara', 2.2630750, 99.5177470, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (42, 2, 'Nias Utara', 1.8876380, 99.3927730, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (43, 2, 'Nias Barat', 2.2162930, 99.9406440, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (44, 3, 'Pesisir Selatan', -0.5044480, 100.3250110, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (45, 3, 'Solok', -1.3319460, 101.0262510, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (46, 3, 'Sijunjung', -0.6013580, 100.8602780, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (47, 3, 'Tanah Datar', -0.8540470, 100.5430670, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (48, 3, 'Padang Pariaman', -0.8572150, 101.1905520, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (49, 3, 'Agam', -0.2982670, 100.5322550, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (50, 3, 'Lima Puluh Kota', -1.3550060, 100.6568300, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (51, 3, 'Pasaman', -0.6539040, 100.9290210, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (52, 3, 'Kepulauan Mentawai', -0.7046980, 100.5189300, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (53, 3, 'Dharmasraya', -1.0386970, 101.0632270, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (54, 3, 'Solok Selatan', -0.2304250, 100.8233630, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (55, 3, 'Pasaman Barat', -1.1854170, 100.3322540, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (56, 4, 'Kampar', 0.2998900, 101.8641750, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (57, 4, 'Indragiri Hulu', 0.4669000, 101.4896510, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (58, 4, 'Bengkalis', -0.0933160, 101.7602750, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (59, 4, 'Indragiri Hilir', 0.7111150, 102.0139750, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (60, 4, 'Pelalawan', 0.1569900, 101.0610050, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (61, 4, 'Rokan Hulu', 0.2183470, 101.8432240, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (62, 4, 'Rokan Hilir', 0.5508510, 101.6215750, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (63, 4, 'Siak', -0.0601130, 101.5337630, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (64, 4, 'Kuantan Singingi', 0.4885160, 102.2015620, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (65, 4, 'Kepulauan Meranti', 0.5088200, 101.0852180, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (66, 5, 'Kerinci', -1.7431750, 103.6858450, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (67, 5, 'Merangin', -1.3493230, 103.6864950, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (68, 5, 'Sarolangun', -1.8196700, 103.2677510, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (69, 5, 'Batanghari', -1.6986840, 104.1404850, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (70, 5, 'Muaro Jambi', -1.1103100, 103.2104240, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (71, 5, 'Tanjung Jabung Barat', -1.7595520, 103.5993930, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (72, 5, 'Tanjung Jabung Timur', -1.4277140, 103.8221380, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (73, 5, 'Bungo', -1.6101230, 103.2036200, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (74, 5, 'Tebo', -1.9546740, 104.0079320, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (75, 6, 'Ogan Komering Ulu', -2.6918340, 104.8570620, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (76, 6, 'Ogan Komering Ilir', -3.4384400, 104.8188360, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (77, 6, 'Muara Enim', -3.2725520, 105.1939090, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (78, 6, 'Lahat', -3.1098900, 104.5693470, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (79, 6, 'Musi Rawas', -3.8120590, 105.0533140, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (80, 6, 'Musi Banyuasin', -2.7606200, 105.2201630, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (81, 6, 'Banyuasin', -3.3707400, 104.7667140, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (82, 6, 'Ogan Komering Ulu Timur', -3.4227620, 105.1766360, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (83, 6, 'Ogan Komering Ulu Selatan', -2.9659770, 104.7416540, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (84, 6, 'Ogan Ilir', -3.8058330, 104.7536880, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (85, 6, 'Empat Lawang', -3.0044370, 105.4875920, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (86, 6, 'Penukal Abab Lematang Ilir', -3.2869710, 104.7609490, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (87, 6, 'Musi Rawas Utara', -3.5406080, 105.0773250, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (88, 7, 'Bengkulu Selatan', -3.1911840, 102.3998380, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (89, 7, 'Rejang Lebong', -3.9056690, 101.9361710, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (90, 7, 'Bengkulu Utara', -3.6053270, 103.0072580, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (91, 7, 'Kaur', -3.4717810, 102.2350190, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (92, 7, 'Seluma', -3.8475900, 102.3587540, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (93, 7, 'Muko-Muko', -3.2790900, 102.6096100, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (94, 7, 'Lebong', -3.6444150, 101.8154690, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (95, 7, 'Kepahiang', -3.9392000, 102.8882570, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (96, 7, 'Bengkulu Tengah', -3.4314030, 102.3122990, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (97, 8, 'Lampung Selatan', -4.7924120, 105.2650580, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (98, 8, 'Lampung Tengah', -4.4413100, 105.7973550, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (99, 8, 'Lampung Utara', -4.3430500, 104.9214800, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (100, 8, 'Lampung Barat', -5.1406290, 105.6599530, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (101, 8, 'Tulang Bawang', -4.4176310, 105.4606760, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (102, 8, 'Tanggamus', -4.6832570, 105.1553400, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (103, 8, 'Lampung Timur', -4.6595240, 105.8023550, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (104, 8, 'Way Kanan', -4.1284550, 105.1190840, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (105, 8, 'Pesawaran', -5.1790140, 105.2919400, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (106, 8, 'Pringsewu', -4.4672710, 105.5317610, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (107, 8, 'Mesuji', -4.5350530, 105.1243870, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (108, 8, 'Tulangbawang Barat', -4.8461230, 105.6834620, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (109, 8, 'Pesisir Barat', -4.0485850, 105.4068080, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (110, 9, 'Bangka', -3.2055360, 105.9936840, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (111, 9, 'Belitung', -2.7279780, 106.5974880, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (112, 9, 'Bangka Selatan', -2.5766850, 106.2156710, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (113, 9, 'Bangka Tengah', -3.1251260, 106.5116960, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (114, 9, 'Bangka Barat', -2.3109210, 106.7283110, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (115, 9, 'Belitung Timur', -2.9041070, 105.8016270, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (116, 10, 'Bintan', 3.8763890, 108.2825710, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (117, 10, 'Karimun', 4.1993680, 108.0459040, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (118, 10, 'Natuna', 3.5853380, 107.9861580, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (119, 10, 'Lingga', 4.1611860, 108.6281950, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (120, 10, 'Kepulauan Anambas', 4.1350960, 107.5119830, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (121, 11, 'Kepulauan Seribu', -5.6122000, 106.5622000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (122, 12, 'Bogor', -6.5971000, 106.8060000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (123, 12, 'Sukabumi', -6.9277000, 106.9300000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (124, 12, 'Cianjur', -6.8173000, 107.1427000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (125, 12, 'Bandung', -6.9175000, 107.6191000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (126, 12, 'Garut', -7.2279000, 107.9087000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (127, 12, 'Tasikmalaya', -7.3274000, 108.2207000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (128, 12, 'Ciamis', -7.3262000, 108.3533000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (129, 12, 'Kuningan', -6.9765000, 108.4831000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (130, 12, 'Cirebon', -6.7320000, 108.5523000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (131, 12, 'Majalengka', -6.8361000, 108.2274000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (132, 12, 'Sumedang', -6.8587000, 107.9266000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (133, 12, 'Indramayu', -6.3264000, 108.3200000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (134, 12, 'Subang', -6.5716000, 107.7587000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (135, 12, 'Purwakarta', -6.5569000, 107.4433000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (136, 12, 'Karawang', -6.3042000, 107.3075000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (137, 12, 'Bekasi', -6.2383000, 106.9756000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (138, 12, 'Bandung Barat', -6.8439000, 107.5029000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (139, 12, 'Pangandaran', -7.6842000, 108.6508000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (140, 13, 'Cilacap', -7.7032000, 109.0159000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (141, 13, 'Banyumas', -7.5144000, 109.2943000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (142, 13, 'Purbalingga', -7.3651800, 110.3128430, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (143, 13, 'Banjarnegara', -6.7624590, 110.1759490, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (144, 13, 'Kebumen', -7.4955260, 109.7454470, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (145, 13, 'Purworejo', -7.1509750, 110.8017590, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (146, 13, 'Wonosobo', -7.0496360, 110.0241380, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (147, 13, 'Magelang', -7.4797000, 110.2177000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (148, 13, 'Boyolali', -6.8415670, 110.3895470, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (149, 13, 'Klaten', -7.2395360, 109.6128940, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (150, 13, 'Sukoharjo', -7.4894740, 110.6981620, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (151, 13, 'Wonogiri', -7.0060860, 110.0994950, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (152, 13, 'Karanganyar', -7.3904680, 110.0093530, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (153, 13, 'Sragen', -7.0175870, 110.5250630, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (154, 13, 'Grobogan', -6.9558060, 109.6455220, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (155, 13, 'Blora', -7.7219490, 110.4198210, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (156, 13, 'Rembang', -7.0079170, 110.1876200, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (157, 13, 'Pati', -6.7547000, 111.0382000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (158, 13, 'Kudus', -6.8048000, 110.8405000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (159, 13, 'Jepara', -6.5936000, 110.6778000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (160, 13, 'Demak', -7.7755850, 110.0539160, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (161, 13, 'Semarang', -6.9667000, 110.4167000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (162, 13, 'Temanggung', -7.1391980, 109.8570290, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (163, 13, 'Kendal', -7.4267470, 110.4298190, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (164, 13, 'Batang', -6.6414600, 110.1169010, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (165, 13, 'Pekalongan', -6.8886000, 109.6753000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (166, 13, 'Pemalang', -7.1313960, 110.2964120, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (167, 13, 'Tegal', -6.8694000, 109.1402000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (168, 13, 'Brebes', -7.5317300, 110.2288910, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (169, 14, 'Kulon Progo', -7.8286000, 110.1583000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (170, 14, 'Bantul', -7.8897000, 110.3297000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (171, 14, 'Gunungkidul', -7.9628000, 110.6042000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (172, 14, 'Sleman', -7.7167000, 110.3556000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (173, 15, 'Pacitan', -7.9025440, 112.0983450, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (174, 15, 'Ponorogo', -7.3005720, 112.7133960, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (175, 15, 'Trenggalek', -7.3730080, 111.5994420, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (176, 15, 'Tulungagung', -7.6625730, 112.3230270, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (177, 15, 'Blitar', -8.0954000, 112.1609000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (178, 15, 'Kediri', -7.8480000, 112.0178000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (179, 15, 'Malang', -7.9666000, 112.6326000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (180, 15, 'Lumajang', -7.0715790, 111.7914990, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (181, 15, 'Jember', -8.1724000, 113.6995000, '2026-10-07 01:37:48', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (182, 15, 'Banyuwangi', -8.2192000, 114.3692000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (183, 15, 'Bondowoso', -7.5700550, 111.8304600, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (184, 15, 'Situbondo', -7.8465320, 112.6632430, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (185, 15, 'Probolinggo', -7.7543000, 113.2159000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (186, 15, 'Pasuruan', -7.6453000, 112.9075000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (187, 15, 'Sidoarjo', -7.4478000, 112.7183000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (188, 15, 'Mojokerto', -7.4726000, 112.4381000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (189, 15, 'Jombang', -8.0153070, 112.4215540, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (190, 15, 'Nganjuk', -6.9540200, 112.4915470, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (191, 15, 'Madiun', -7.6298000, 111.5239000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (192, 15, 'Magetan', -7.6172550, 112.5087810, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (193, 15, 'Ngawi', -7.1983140, 112.0336520, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (194, 15, 'Bojonegoro', -8.0339750, 112.1224990, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (195, 15, 'Tuban', -7.1747110, 112.7802710, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (196, 15, 'Lamongan', -7.5164850, 112.0822490, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (197, 15, 'Gresik', -7.1566000, 112.6555000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (198, 15, 'Bangkalan', -7.1464350, 112.2562640, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (199, 15, 'Sampang', -7.8966880, 111.8597460, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (200, 15, 'Pamekasan', -7.5085840, 112.8992720, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (201, 15, 'Sumenep', -7.4396460, 112.1177500, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (202, 16, 'Pandeglang', -6.6735070, 106.1010220, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (203, 16, 'Lebak', -6.0863480, 106.2988980, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (204, 16, 'Tangerang', -6.5162010, 105.5412110, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (205, 16, 'Serang', -6.7208170, 106.6368940, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (206, 17, 'Jembrana', -8.3079000, 114.6657000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (207, 17, 'Tabanan', -8.5385000, 115.1245000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (208, 17, 'Badung', -8.5819000, 115.1771000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (209, 17, 'Gianyar', -8.5434000, 115.3262000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (210, 17, 'Klungkung', -8.5358000, 115.4038000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (211, 17, 'Bangli', -8.4543000, 115.3549000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (212, 17, 'Karangasem', -8.4485000, 115.6128000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (213, 17, 'Buleleng', -8.2415000, 114.9701000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (214, 18, 'Lombok Barat', -8.2483230, 117.0356560, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (215, 18, 'Lombok Tengah', -9.2805360, 117.3039940, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (216, 18, 'Lombok Timur', -8.5515940, 117.4777690, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (217, 18, 'Sumbawa', -8.6529330, 117.0781480, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (218, 18, 'Dompu', -8.9164130, 117.6635630, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (219, 18, 'Bima', -8.1448740, 117.3149760, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (220, 18, 'Sumbawa Barat', -9.1527460, 116.9589520, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (221, 18, 'Lombok Utara', -8.6268860, 117.5167550, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (222, 19, 'Kupang', -8.5123110, 120.8402700, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (223, 19, 'Timor Tengah Selatan', -9.0340930, 121.1853570, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (224, 19, 'Timor Tengah Utara', -8.2050060, 121.3266370, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (225, 19, 'Belu', -8.8728550, 120.4577640, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (226, 19, 'Alor', -8.7147850, 121.2248820, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (227, 19, 'Flores Timur', -8.4126790, 120.9595590, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (228, 19, 'Sikka', -9.0293320, 120.9562320, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (229, 19, 'Ende', -8.4023820, 121.5431280, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (230, 19, 'Ngada', -8.5210250, 120.4335510, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (231, 19, 'Manggarai', -8.7802550, 121.1697090, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (232, 19, 'Sumba Timur', -8.3896920, 121.1163750, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (233, 19, 'Sumba Barat', -8.9080690, 120.7656760, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (234, 19, 'Lembata', -8.6796280, 121.6143610, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (235, 19, 'Rote Ndao', -8.2119050, 120.6116200, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (236, 19, 'Manggarai Barat', -8.8072390, 121.0862410, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (237, 19, 'Nagekeo', -8.4505500, 121.2616010, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (238, 19, 'Sumba Tengah', -8.7082870, 120.6733740, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (239, 19, 'Sumba Barat Daya', -8.9499060, 121.5180270, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (240, 19, 'Manggarai Timur', -8.0423160, 120.9361960, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (241, 19, 'Sabu Raijua', -8.7872860, 121.0006210, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (242, 19, 'Malaka', -8.5761910, 121.3497500, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (243, 20, 'Sambas', -0.1139600, 111.1041520, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (244, 20, 'Mempawah', -0.7499600, 111.6802120, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (245, 20, 'Sanggau', 0.3132250, 111.7015310, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (246, 20, 'Ketapang', -0.3480430, 111.3355810, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (247, 20, 'Sintang', -0.3486620, 111.7491250, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (248, 20, 'Kapuas Hulu', 0.0501420, 111.2552610, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (249, 20, 'Bengkayang', -0.7810330, 111.3822960, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (250, 20, 'Landak', 0.1047390, 112.0000880, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (251, 20, 'Sekadau', -0.2657080, 111.3183840, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (252, 20, 'Melawi', -0.4778460, 111.6668150, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (253, 20, 'Kayong Utara', 0.1112190, 111.4752850, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (254, 20, 'Kubu Raya', -0.6547920, 111.1135060, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (255, 21, 'Kotawaringin Barat', -1.6265800, 114.0413380, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (256, 21, 'Kotawaringin Timur', -1.5901740, 113.2574020, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (257, 21, 'Kapuas', -1.9473860, 113.4315840, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (258, 21, 'Barito Selatan', -1.3525650, 113.6023790, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (259, 21, 'Barito Utara', -1.8134860, 112.8651020, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (260, 21, 'Katingan', -1.9723900, 113.9691130, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (261, 21, 'Seruyan', -1.5405340, 113.3284870, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (262, 21, 'Sukamara', -1.9309350, 113.2738640, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (263, 21, 'Lamandau', -1.5166670, 113.7534880, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (264, 21, 'Gunung Mas', -1.5281280, 112.8716400, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (265, 21, 'Pulang Pisau', -2.2270840, 113.7131050, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (266, 21, 'Murung Raya', -1.5350440, 113.4164440, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (267, 21, 'Barito Timur', -1.8363540, 113.1501250, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (268, 22, 'Tanah Laut', -3.1435460, 115.6897560, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (269, 22, 'Kotabaru', -2.7019580, 114.9395460, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (270, 22, 'Banjar Baru', -3.7220410, 115.2549050, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (271, 22, 'Barito Kuala', -2.9865750, 115.3951280, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (272, 22, 'Tapin', -3.1044180, 115.0005290, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (273, 22, 'Hulu Sungai Selatan', -3.3433280, 115.5974540, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (274, 22, 'Hulu Sungai Tengah', -2.5870040, 115.2138620, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (275, 22, 'Hulu Sungai Utara', -3.6087070, 114.9043380, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (276, 22, 'Tabalong', -3.0601750, 115.4375260, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (277, 22, 'Tanah Bumbu', -2.9576410, 115.0382410, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (278, 22, 'Balangan', -3.4645910, 115.4068980, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (279, 23, 'Paser', 1.0008760, 116.6457010, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (280, 23, 'Kutai Kartanegara', 0.2975680, 115.8082430, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (281, 23, 'Berau', 0.4873560, 116.5673910, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (282, 23, 'Kutai Barat', 0.7781520, 116.2884830, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (283, 23, 'Kutai Timur', 0.1619480, 116.3134030, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (284, 23, 'Penajam Paser Utara', 0.8126820, 116.8710250, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (285, 23, 'Mahakam Ulu', 0.6480570, 115.7679390, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (286, 24, 'Bulungan', 2.9540900, 116.1372700, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (287, 24, 'Malinau', 3.3420660, 116.0660990, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (288, 24, 'Nunukan', 2.8096130, 115.7394750, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (289, 24, 'Tana Tidung', 3.0730930, 116.5768900, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (290, 25, 'Bolaang Mongondow', 1.0503150, 123.4872930, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (291, 25, 'Minahasa', 0.4752640, 123.9887290, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (292, 25, 'Kepulauan Sangihe', 0.8388980, 124.1475860, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (293, 25, 'Kepulauan Talaud', 0.5569700, 123.5717230, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (294, 25, 'Minahasa Selatan', 0.3506700, 124.4266380, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (295, 25, 'Minahasa Utara', 1.2332260, 123.8037930, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (296, 25, 'Minahasa Tenggara', 0.4916410, 123.9022770, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (297, 25, 'Bolaang Mongondow Utara', 0.7170380, 124.2414050, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (298, 25, 'Kepulauan Siau Tagulandang Biaro', 0.7739400, 123.5966730, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (299, 25, 'Bolaang Mongondow Timur', 0.1624760, 124.2013140, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (300, 25, 'Bolaang Mongondow Selatan', 1.2255350, 124.1739190, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (301, 26, 'Banggai', -1.5050250, 121.3092190, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (302, 26, 'Poso', -1.4884640, 121.7223980, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (303, 26, 'Donggala', -1.1105560, 121.2107380, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (304, 26, 'Toli-Toli', -1.9356620, 121.3757210, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (305, 26, 'Buol', -1.0250690, 121.9523560, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (306, 26, 'Morowali', -1.4234820, 121.2882680, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (307, 26, 'Banggai Kepulauan', -1.6209440, 121.6460830, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (308, 26, 'Parigi Moutong', -1.0403960, 121.4277560, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (309, 26, 'Tojo Una-Una', -1.8207080, 121.1014050, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (310, 26, 'Sigi', -1.3477930, 122.1014590, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (311, 26, 'Banggai Laut', -1.3439890, 121.3166020, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (312, 26, 'Morowali Utara', -1.6936250, 121.5069790, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (313, 27, 'Kepulauan Selayar', -3.3310490, 120.1788030, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (314, 27, 'Bulukumba', -3.8221590, 119.4633380, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (315, 27, 'Bantaeng', -3.9350490, 120.5735760, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (316, 27, 'Jeneponto', -3.5302170, 119.9137800, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (317, 27, 'Takalar', -3.9225160, 119.8770900, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (318, 27, 'Gowa', -3.4887170, 120.3372840, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (319, 27, 'Sinjai', -3.5368010, 119.4568000, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (320, 27, 'Bone', -4.2001360, 120.3294770, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (321, 27, 'Maros', -3.5210780, 120.0014030, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (322, 27, 'Pangkajene Kepulauan', -3.8331650, 119.7491370, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (323, 27, 'Barru', -3.7027900, 120.3819950, '2026-10-07 01:37:49', '2026-10-07 02:29:17');
INSERT INTO `kabupatens` VALUES (324, 27, 'Soppeng', -3.2927880, 119.6122740, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (325, 27, 'Wajo', -4.2987990, 119.9740530, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (326, 27, 'Sidenreng Rappang', -3.5582070, 120.0804580, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (327, 27, 'Pinrang', -3.6923310, 119.6916320, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (328, 27, 'Enrekang', -3.9062160, 120.2989310, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (329, 27, 'Luwu', -3.1665470, 119.8810640, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (330, 27, 'Tana Toraja', -4.2001360, 119.6186290, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (331, 27, 'Luwu Utara', -3.6299760, 120.1261860, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (332, 27, 'Luwu Timur', -3.5441270, 119.7225850, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (333, 27, 'Toraja Utara', -4.0352790, 120.1141100, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (334, 28, 'Kolaka', -3.6737310, 122.3795320, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (335, 28, 'Konawe', -4.4111600, 121.5750820, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (336, 28, 'Muna', -4.1900160, 122.3248150, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (337, 28, 'Buton', -3.9110830, 122.0328550, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (338, 28, 'Konawe Selatan', -4.5256650, 122.0859730, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (339, 28, 'Bombana', -3.8523860, 122.6132610, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (340, 28, 'Wakatobi', -4.0626780, 121.5187640, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (341, 28, 'Kolaka Utara', -4.2598170, 122.2758440, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (342, 28, 'Konawe Utara', -3.8751670, 122.1869710, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (343, 28, 'Buton Utara', -4.4206820, 121.8850450, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (344, 28, 'Kolaka Timur', -4.1226640, 122.7095950, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (345, 28, 'Konawe Kepulauan', -3.7399540, 121.6678670, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (346, 28, 'Muna Barat', -4.2936270, 122.1951630, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (347, 28, 'Buton Tengah', -3.9237390, 122.3372140, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (348, 28, 'Buton Selatan', -4.2293210, 121.7748120, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (349, 29, 'Gorontalo', 0.5435000, 123.0568000, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (350, 29, 'Boalemo', 0.6555000, 122.3374000, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (351, 29, 'Bone Bolango', 0.5312000, 123.2384000, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (352, 29, 'Pohuwato', 0.5186000, 121.7516000, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (353, 29, 'Gorontalo Utara', 0.7712000, 122.8687000, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (354, 30, 'Pasangkayu', -3.2965130, 119.4793440, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (355, 30, 'Mamuju', -2.2356040, 119.4032870, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (356, 30, 'Mamasa', -2.9247320, 119.0992440, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (357, 30, 'Majene', -2.8910220, 119.5112710, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (358, 30, 'Polewali Mandar', -2.5347290, 118.9827900, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (359, 30, 'Mamuju Tengah', -3.3521960, 119.1854060, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (360, 31, 'Maluku Tengah', -2.8128400, 130.6329820, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (361, 31, 'Maluku Tenggara', -3.2384620, 129.9877730, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (362, 31, 'Kepulauan Tanimbar', -3.4208710, 130.3542910, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (363, 31, 'Buru', -2.8499460, 130.1095830, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (364, 31, 'Seram Bagian Timur', -3.6430720, 129.8192810, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (365, 31, 'Seram Bagian Barat', -3.1290640, 130.7967230, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (366, 31, 'Kepulauan Aru', -3.1578670, 130.0124390, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (367, 31, 'Maluku Barat Daya', -3.4992620, 130.2186480, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (368, 31, 'Buru Selatan', -2.8925280, 130.3343590, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (369, 32, 'Halmahera Barat', 1.3965690, 127.3055640, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (370, 32, 'Halmahera Tengah', 1.3299080, 128.4199150, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (371, 32, 'Halmahera Utara', 1.7069450, 127.7422070, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (372, 32, 'Halmahera Selatan', 1.3134950, 127.7235190, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (373, 32, 'Kepulauan Sula', 1.7659990, 128.1634060, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (374, 32, 'Halmahera Timur', 1.6813830, 127.2859620, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (375, 32, 'Pulau Morotai', 1.0549330, 128.1881900, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (376, 32, 'Pulau Taliabu', 1.7197160, 127.8293270, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (377, 33, 'Merauke', -4.4434810, 137.8631790, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (378, 33, 'Jayawijaya', -4.2869400, 138.4894630, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (379, 33, 'Jayapura', -3.9093040, 137.7016970, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (380, 33, 'Nabire', -4.8993280, 138.1092070, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (381, 33, 'Kepulauan Yapen', -4.1550210, 138.1815920, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (382, 33, 'Biak Numfor', -4.3051700, 137.7992780, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (383, 33, 'Puncak Jaya', -4.4936230, 138.4157960, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (384, 33, 'Paniai', -3.7720170, 137.9644500, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (385, 33, 'Mimika', -4.8155240, 137.7496030, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (386, 33, 'Sarmi', -4.2248220, 138.2305630, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (387, 33, 'Keerom', -4.1558210, 137.8234150, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (388, 33, 'Pegunungan Bintang', -4.6302410, 138.2370620, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (389, 33, 'Yahukimo', -3.7906850, 138.2635050, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (390, 33, 'Tolikara', -4.5608300, 137.4935950, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (391, 33, 'Waropen', -4.3087510, 138.2324860, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (392, 33, 'Boven Digoel', -4.0422120, 137.9280290, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (393, 33, 'Mappi', -4.6540030, 138.0092440, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (394, 33, 'Asmat', -3.9594600, 138.5051940, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (395, 33, 'Supiori', -4.2150200, 137.4213700, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (396, 33, 'Mamberamo Raya', -4.3805200, 138.1867580, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (397, 33, 'Mamberamo Tengah', -3.9999280, 138.0803530, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (398, 33, 'Yalimo', -4.5574660, 137.8036990, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (399, 33, 'Lanny Jaya', -4.2254790, 138.6138150, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (400, 33, 'Nduga', -3.8864080, 137.5555500, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (401, 33, 'Puncak', -4.4176490, 138.1077030, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (402, 33, 'Dogiyai', -4.0422120, 138.2326770, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (403, 33, 'Intan Jaya', -4.3708670, 137.6848060, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (404, 33, 'Deiyai', -4.5054200, 138.5553470, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (405, 34, 'Sorong', -0.7441090, 132.9484700, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (406, 34, 'Manokwari', -1.4746970, 133.1144430, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (407, 34, 'Fak Fak', -1.2220080, 133.4316540, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (408, 34, 'Sorong Selatan', -1.2188400, 132.7841690, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (409, 34, 'Raja Ampat', -1.7777880, 133.4424660, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (410, 34, 'Teluk Bintuni', -0.7210490, 133.3178910, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (411, 34, 'Teluk Wondama', -1.4221510, 133.0457000, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (412, 34, 'Kaimana', -1.3713570, 133.4557910, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (413, 34, 'Tambrauw', -1.0373580, 132.9114940, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (414, 34, 'Maybrat', -1.8456300, 133.1513580, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (415, 34, 'Manokwari Selatan', -0.8906380, 133.6424670, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (416, 34, 'Pegunungan Arfak', -1.3426580, 133.0173660, '2026-10-07 01:37:49', '2026-10-07 02:29:18');
INSERT INTO `kabupatens` VALUES (417, 13, 'Salatiga', -7.3245280, 110.3574330, '2026-10-07 02:03:10', '2026-10-07 02:29:18');

-- -----------------------------------------------------
-- Table structure for `kategori_ujis`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `kategori_ujis`;
CREATE TABLE `kategori_ujis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kategori` enum('nyamuk','insektisida','metode') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `kategori_ujis`
INSERT INTO `kategori_ujis` VALUES (1, 'nyamuk', 'Ae. aegypti', 'Vektor utama demam berdarah dengue (DBD)', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (2, 'nyamuk', 'Culex sp', 'Vektor filariasis dan ensefalitis jepang', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (3, 'nyamuk', 'Anhopheles', 'Vektor penular malaria', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (4, 'nyamuk', 'Aedes sp', 'Vektor arbovirus umum', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (5, 'nyamuk', 'An. Farauti', 'Vektor malaria wilayah pesisir/kepulauan', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (6, 'nyamuk', 'An. Vagus', 'Spesies vektor malaria sekunder', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (7, 'nyamuk', 'An. tessellatus', 'Spesies nyamuk anopheles', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (8, 'nyamuk', 'An. sundaicus s.I', 'Vektor malaria air payau/pesisir', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (9, 'nyamuk', 'An. punctulatus s.I.', 'Vektor malaria di wilayah timur', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (10, 'nyamuk', 'An. peditaeniatus', 'Spesies nyamuk vektor', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (11, 'nyamuk', 'An. parensis', 'Spesies nyamuk anopheles', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (12, 'nyamuk', 'An. letifer', 'Vektor malaria dataran rendah/hutan', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (13, 'nyamuk', 'An. koliensis', 'Vektor malaria regional', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (14, 'nyamuk', 'An. kochi', 'Spesies anopheles area perbukitan', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (15, 'nyamuk', 'An. indefinitus', 'Spesies nyamuk vektor', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (16, 'nyamuk', 'An. hyrcanus s.I.', 'Kelompok spesies hyrcanus', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (17, 'nyamuk', 'An. farauti s.s', 'Vektor malaria pesisir timur', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (18, 'nyamuk', 'An. barbirostris', 'Vektor malaria dan filariasis', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (19, 'nyamuk', 'An. aconitus', 'Vektor malaria sawah dataran rendah', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (20, 'nyamuk', 'An. Albopictus', 'Vektor sekunder DBD dan chikungunya', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (21, 'insektisida', 'Cypermethrin', 'Piretroid sintetik spektrum luas', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (22, 'insektisida', 'Lamdacyhalothrin', 'Piretroid sintetik efektif residu tinggi', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (23, 'insektisida', 'Deltamethrin', 'Piretroid sintetik untuk kelambu dan IRS', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (24, 'insektisida', 'Alphacypermethrin', 'Isomer aktif sipermetrin', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (25, 'insektisida', 'Cyfluthrin', 'Insektisida piretroid untuk pengendalian vektor', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (26, 'insektisida', 'Permethrin', 'Piretroid umum untuk pencelupan kelambu', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (27, 'insektisida', 'Malathion', 'Organofosfat untuk pengasapan (fogging)', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (28, 'insektisida', 'Deltamethrin 0,025%', 'Formulasi standar kertas uji WHO', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (29, 'insektisida', 'Lambda-cyhalothrin 0,0025%', 'Formulasi dosis diagnostik', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (30, 'insektisida', 'Temefos (Abate)', 'Larvasida organofosfat untuk air bersih', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (31, 'insektisida', 'Bendiocarb', 'Karbamat untuk penyemprotan dinding (IRS)', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (32, 'insektisida', 'Sipermethrin', 'Formulasi varian sipermetrin', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (33, 'metode', 'Sequencing', 'Deteksi mutasi genetik resistensi (kdr)', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (34, 'metode', 'WHO Tube Bioassay', 'Uji kerentanan standar WHO menggunakan tabung uji', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (35, 'metode', 'WHO larval bioassay', 'Bioassay larva standar WHO untuk larvasida', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (36, 'metode', 'WHO susceptibilitity test', 'Protokol diagnostik kerentanan vektor WHO', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (37, 'metode', 'WHO test kit_adults', 'Paket uji standar WHO untuk nyamuk dewasa', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (38, 'metode', 'CDC bottle_adults', 'Bioassay botol CDC untuk nyamuk dewasa', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (39, 'metode', 'CDC bottle bioassay', 'Protokol uji resistensi botol CDC diagnostik waktu', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');
INSERT INTO `kategori_ujis` VALUES (40, 'metode', 'WHO standards bioassay', 'Bioassay acuan standar laboratorium WHO', 1, '2026-10-07 03:36:02', '2026-10-07 03:36:02');

-- -----------------------------------------------------
-- Table structure for `migrations`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `migrations`
INSERT INTO `migrations` VALUES (1, '2014_10_12_000000_create_users_table', 1);
INSERT INTO `migrations` VALUES (2, '2014_10_12_100000_create_password_reset_tokens_table', 1);
INSERT INTO `migrations` VALUES (3, '2019_08_19_000000_create_failed_jobs_table', 1);
INSERT INTO `migrations` VALUES (4, '2019_12_14_000001_create_personal_access_tokens_table', 1);
INSERT INTO `migrations` VALUES (5, '2026_10_02_042253_create_provinsis_table', 1);
INSERT INTO `migrations` VALUES (6, '2026_10_02_042405_create_kabupatens_table', 1);
INSERT INTO `migrations` VALUES (7, '2026_10_02_042603_create_data_uji_resistensis_table', 1);
INSERT INTO `migrations` VALUES (8, '2026_10_03_154503_add_bulan_tahun_to_data_uji_resistensis_table', 1);
INSERT INTO `migrations` VALUES (9, '2026_10_05_064035_hapus_bulan_tahun_dari_data_uji_resistensis', 1);
INSERT INTO `migrations` VALUES (10, '2026_10_05_070843_hapus_sampel_dari_data_uji_resistensis', 1);
INSERT INTO `migrations` VALUES (11, '2026_10_05_071004_hapus_sampel_dan_rekap_dari_data_uji_resistensis', 1);
INSERT INTO `migrations` VALUES (12, '2026_10_05_072912_tambah_koordinat_ke_kabupaten', 1);
INSERT INTO `migrations` VALUES (13, '2026_10_06_020741_create_delete_requests_table', 1);
INSERT INTO `migrations` VALUES (14, '2026_10_06_044112_add_bulan_tahun_to_data_uji_resistensis_table', 1);
INSERT INTO `migrations` VALUES (15, '2026_10_07_015109_create_instansis_table', 2);
INSERT INTO `migrations` VALUES (16, '2026_10_07_021151_add_alamat_to_data_uji_resistensis_table', 3);
INSERT INTO `migrations` VALUES (17, '2026_10_07_033500_create_kategori_ujis_table', 4);

-- -----------------------------------------------------
-- Table structure for `password_reset_tokens`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------
-- Table structure for `personal_access_tokens`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------
-- Table structure for `provinsis`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `provinsis`;
CREATE TABLE `provinsis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama_provinsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for `provinsis`
INSERT INTO `provinsis` VALUES (1, 'Aceh', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (2, 'Sumatera Utara', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (3, 'Sumatera Barat', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (4, 'Riau', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (5, 'Jambi', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (6, 'Sumatera Selatan', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (7, 'Bengkulu', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (8, 'Lampung', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (9, 'Kepulauan Bangka Belitung', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (10, 'Kepulauan Riau', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (11, 'DKI Jakarta', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (12, 'Jawa Barat', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (13, 'Jawa Tengah', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (14, 'DI Yogyakarta', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (15, 'Jawa Timur', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (16, 'Banten', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (17, 'Bali', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (18, 'Nusa Tenggara Barat', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (19, 'Nusa Tenggara Timur', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (20, 'Kalimantan Barat', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (21, 'Kalimantan Tengah', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (22, 'Kalimantan Selatan', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (23, 'Kalimantan Timur', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (24, 'Kalimantan Utara', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (25, 'Sulawesi Utara', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (26, 'Sulawesi Tengah', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (27, 'Sulawesi Selatan', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (28, 'Sulawesi Tenggara', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (29, 'Gorontalo', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (30, 'Sulawesi Barat', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (31, 'Maluku', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (32, 'Maluku Utara', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (33, 'Papua', '2026-10-07 01:37:48', '2026-10-07 01:37:48');
INSERT INTO `provinsis` VALUES (34, 'Papua Barat', '2026-10-07 01:37:48', '2026-10-07 01:37:48');

-- -----------------------------------------------------
-- Table structure for `users`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
